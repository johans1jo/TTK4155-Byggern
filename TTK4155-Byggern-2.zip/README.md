# Byggern (Maxbo?)

Prosjekt i faget **TTK4155 - Industrielle og innbygde datasystemers konstruksjon** aka **Byggern**

Det ambisiøse og framoverlente teamet bestod av følgende partnere:

* National Integration Orchastrator **Jo Aleksander Johansen** ([@johans1jo](https://github.com/johans1jo))
* Key Account Manager **Max Robertson** ([@maxmrmr](https://github.com/maxmrmr))
* Dynamic Mobility Operator **Erlend Blomseth** ([@erlendb](https://github.com/erlendb))

## Bugs
* OLEDen er jo helt kaos, hva skjer
* Bør gå over til interrupts på ADC. Lite delay skaper kaos i lesingen
* Menyen dobles når man trykker reset-knappen :)
