static unsigned int pwm_period;

void pwm_init();
void pwm_set_ms(double ms);
