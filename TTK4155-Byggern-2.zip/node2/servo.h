void servo_set_angle(double angle);
void servo_set_from_joystick(int y);

int joy_to_deg(int pos);
