void solenoid_init();
void solenoid_set();
void solenoid_clear();
int solenoid_is_set();
void solenoid_fire();
