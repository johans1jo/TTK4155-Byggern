enum {
	IDLE = 0,
  GAME = 1
};

void mode_set(int m);
int mode_get();
