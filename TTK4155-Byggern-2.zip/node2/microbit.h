#include <avr/io.h>
#include <stdio.h>

void microbit_init();
int microbit_read_servo_input();
int microbit_read_solenoid_input();
int microbit_read_speed_input();
